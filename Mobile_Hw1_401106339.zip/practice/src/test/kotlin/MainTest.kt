import org.example.*
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.PrintStream

class MainTest {
    private val originalOut = System.out
    private val originalIn = System.`in`
    private lateinit var outputStream: ByteArrayOutputStream

    @BeforeEach
    fun setUp() {
        // جهت گرفتن خروجی متدهای چاپ (System.out)
        outputStream = ByteArrayOutputStream()
        System.setOut(PrintStream(outputStream))
        // پاکسازی Cache قبل از هر تست
        UserCache.cache.clear()
    }

    @AfterEach
    fun tearDown() {
        System.setOut(originalOut)
        System.setIn(originalIn)
    }

    @Test
    fun testDisplayCachedUsers() {
        // افزودن نمونه کاربر به Cache
        val user1 = GitHubUser("user1", 10, 5, "2020-01-01T00:00:00Z")
        val user2 = GitHubUser("user2", 20, 10, "2021-01-01T00:00:00Z")
        UserCache.cache["user1"] = Pair(user1, listOf(Repository("repo1"), Repository("repo2")))
        UserCache.cache["user2"] = Pair(user2, listOf(Repository("repo3")))

        // فراخوانی تابع نمایش کاربران
        displayCachedUsers()

        val output = outputStream.toString()
        assertTrue(output.contains("user1"), "خروجی باید شامل user1 باشد")
        assertTrue(output.contains("user2"), "خروجی باید شامل user2 باشد")
        assertTrue(output.contains("10"), "خروجی باید شامل تعداد فالوورها (10) باشد")
        assertTrue(output.contains("20"), "خروجی باید شامل تعداد فالوورها (20) باشد")
    }

    @Test
    fun testSearchUserByUsername() {
        // افزودن نمونه کاربر به Cache
        val user1 = GitHubUser("Alice", 5, 2, "2022-01-01T00:00:00Z")
        val user2 = GitHubUser("Bob", 15, 7, "2021-05-05T00:00:00Z")
        UserCache.cache["Alice"] = Pair(user1, listOf(Repository("repoA")))
        UserCache.cache["Bob"] = Pair(user2, listOf(Repository("repoB")))

        // شبیه‌سازی ورودی کاربر برای جستجو (مثلاً "Alice")
        System.setIn(ByteArrayInputStream("Alice\n".toByteArray()))
        searchUserByUsername()
        val output = outputStream.toString()
        assertTrue(output.contains("Alice"), "خروجی باید شامل Alice باشد")
        assertTrue(!output.contains("Bob"), "خروجی نباید شامل Bob باشد")
    }

    @Test
    fun testSearchUserByRepository() {
        // افزودن نمونه کاربر به Cache
        val user1 = GitHubUser("Alice", 5, 2, "2022-01-01T00:00:00Z")
        val user2 = GitHubUser("Bob", 15, 7, "2021-05-05T00:00:00Z")
        UserCache.cache["Alice"] = Pair(user1, listOf(Repository("commonRepo")))
        UserCache.cache["Bob"] = Pair(user2, listOf(Repository("differentRepo")))

        // شبیه‌سازی ورودی برای جستجوی ریپوزیتوری ("commonRepo")
        System.setIn(ByteArrayInputStream("commonRepo\n".toByteArray()))
        searchUserByRepository()
        val output = outputStream.toString()
        assertTrue(output.contains("Alice"), "خروجی باید شامل Alice باشد")
        assertTrue(!output.contains("Bob"), "خروجی نباید شامل Bob باشد")
    }
}
