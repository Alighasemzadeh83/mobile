package org.example

data class Repository(
    val name: String
)
