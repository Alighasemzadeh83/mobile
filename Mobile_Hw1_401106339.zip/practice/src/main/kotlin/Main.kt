package org.example

fun main() {
    while (true) {
        println(
            """
            لطفاً یک گزینه را انتخاب کنید:
            1. دریافت اطلاعات کاربر بر اساس نام کاربری
            2. نمایش لیست کاربران موجود در حافظه
            3. جستجو بر اساس نام کاربری
            4. جستجو بر اساس نام ریپوزیتوری
            5. خروج از برنامه
            """.trimIndent()
        )

        when (readLine()?.trim()) {
            "1" -> fetchAndCacheUser()
            "2" -> displayCachedUsers()
            "3" -> searchUserByUsername()
            "4" -> searchUserByRepository()
            "5" -> {
                println("خروج از برنامه.")
                return
            }
            else -> println("گزینه نامعتبر است. دوباره امتحان کنید.")
        }
    }
}

fun fetchAndCacheUser() {
    print("نام کاربری گیت‌هاب را وارد کنید: ")
    val username = readLine()?.trim() ?: return
    if (UserCache.cache.containsKey(username)) {
        println("اطلاعات $username از قبل دریافت شده است.")
        return
    }

    val userCall = ApiClient.api.getUser(username)
    val repoCall = ApiClient.api.getUserRepos(username)

    try {
        val userResponse = userCall.execute()
        val repoResponse = repoCall.execute()

        if (userResponse.isSuccessful && repoResponse.isSuccessful) {
            val user = userResponse.body()!!
            val repos = repoResponse.body() ?: emptyList()
            UserCache.cache[username] = Pair(user, repos)
            println("اطلاعات کاربر $username با موفقیت دریافت شد.")
        } else {
            println("خطا در دریافت اطلاعات. کد وضعیت: ${userResponse.code()} / ${repoResponse.code()}")
        }
    } catch (e: Exception) {
        println("خطا در برقراری ارتباط: ${e.message}")
    }
}

fun displayCachedUsers() {
    if (UserCache.cache.isEmpty()) {
        println("هیچ کاربری در حافظه موجود نیست.")
    } else {
        UserCache.cache.forEach { (username, pair) ->
            println("نام کاربری: $username | تعداد فالوورها: ${pair.first.followers} | تعداد فالووینگ: ${pair.first.following}")
        }
    }
}

fun searchUserByUsername() {
    print("نام کاربری برای جستجو را وارد کنید: ")
    val query = readLine()?.trim() ?: return
    val results = UserCache.cache.filter { it.key.contains(query, ignoreCase = true) }
    if (results.isEmpty()) {
        println("هیچ کاربری مطابق با '$query' پیدا نشد.")
    } else {
        results.forEach { (username, pair) ->
            println("نام کاربری: $username | تعداد فالوورها: ${pair.first.followers} | تعداد فالووینگ: ${pair.first.following}")
        }
    }
}

fun searchUserByRepository() {
    print("نام ریپوزیتوری برای جستجو را وارد کنید: ")
    val repoQuery = readLine()?.trim() ?: return
    val matchingUsers = mutableSetOf<String>()
    UserCache.cache.forEach { (username, pair) ->
        if (pair.second.any { it.name.contains(repoQuery, ignoreCase = true) }) {
            matchingUsers.add(username)
        }
    }
    if (matchingUsers.isEmpty()) {
        println("هیچ ریپوزیتوری مطابق با '$repoQuery' پیدا نشد.")
    } else {
        println("کاربران دارای ریپوزیتوری مطابق:")
        matchingUsers.forEach { println(it) }
    }
}
