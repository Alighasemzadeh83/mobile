package org.example

object UserCache {
    val cache = mutableMapOf<String, Pair<GitHubUser, List<Repository>>>()
}